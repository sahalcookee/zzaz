<?php
require_once('mailer.php');

send_email("Test Subject", "<h1>Test body</h1>");